import React from 'react';
import AppNavbar from './components/Navbar';
import SearchForm from './components/SearchForm';


function App() {
  return (
    <div>
      <AppNavbar />
      <SearchForm />
    </div>
  );
}

export default App;
