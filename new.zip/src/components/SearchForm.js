import React from 'react';
import { Form, Row, Col, Button, Container } from 'react-bootstrap';

const SearchForm = () => {
  return (
    <Container className="mt-4">
      <h2>Search cars</h2>
      <Form>
        <Row>
          <Col md={6} xs={12}>
            <Form.Group controlId="formPickUp">
              <Form.Label>Pick-up</Form.Label>
              <Form.Control type="text" placeholder="Pick-up location" />
            </Form.Group>
          </Col>
          <Col md={6} xs={12}>
            <Form.Group controlId="formDropOff">
              <Form.Check type="checkbox" label="Same as pick-up" />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col md={6} xs={12}>
            <Form.Group controlId="formPickUpDate">
              <Form.Label>Pick-up date</Form.Label>
              <Form.Control type="date" />
            </Form.Group>
          </Col>
          <Col md={6} xs={12}>
            <Form.Group controlId="formDropOffDate">
              <Form.Label>Drop-off date</Form.Label>
              <Form.Control type="date" />
            </Form.Group>
          </Col>
        </Row>
        <Row>
          <Col md={6} xs={12}>
            <Form.Group controlId="formPickUpTime">
              <Form.Label>Pick-up time</Form.Label>
              <Form.Control type="time" />
            </Form.Group>
          </Col>
          <Col md={6} xs={12}>
            <Form.Group controlId="formDropOffTime">
              <Form.Label>Drop-off time</Form.Label>
              <Form.Control type="time" />
            </Form.Group>
          </Col>
        </Row>
        <Form.Group className="mt-3">
          <Button variant="primary" type="submit">Search</Button>
        </Form.Group>
      </Form>
    </Container>
  );
};

export default SearchForm;
